# IG Feed Mockup

A Pen created on CodePen.

Original URL: [https://codepen.io/Sauda-the-lessful/pen/myJYBWv](https://codepen.io/Sauda-the-lessful/pen/myJYBWv).

It is an IG feed mockup that enables you to preview your feed before publishing